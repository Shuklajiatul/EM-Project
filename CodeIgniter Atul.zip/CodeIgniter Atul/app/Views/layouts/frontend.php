<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CodeIgniter 4</title>
  <link href="<?= base_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.bootstrap5.css">
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.14.0/build/css/alertify.min.css"/>
</head>

<body>

  <div class="app">
    <?= $this->include('layouts/inc/navbar.php') ?>
    <?= $this->renderSection('content') ?>
  </div>

  <script src="<?= base_url('assets/js/jquery-3.7.1.js') ?>" crossorigin="anonymous"></script>
  <script src="<?= base_url('assets/js/popper.min.js') ?>" crossorigin="anonymous"></script>
  <script src="<?= base_url('assets/js/bootstrap.min.js') ?>" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
  <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.14.0/build/alertify.min.js"></script>
  <script>
    $(document).ready(function () {
      <?php if (session()->getFlashdata('status')) { ?>
      alertify.set('notifier','position', 'top-right');
      alertify.success("<?= session()->getFlashdata('status') ?>");
      <?php } ?>
    });
    
  </script>
  <script src="https://cdn.datatables.net/2.1.8/js/dataTables.js"></script>
  <script src="https://cdn.datatables.net/2.1.8/js/dataTables.bootstrap5.js"></script>
  <?= $this->renderSection('scripts') ?>
  <script>
    $(document).ready(function() {
      $('#myDataTable').DataTable({
        pageLength: 8, // Set the number of entries per page to 8
        lengthMenu: [8, 16, 24, 32], // Optional: Allow users to select different page lengths
        pagingType: 'full_numbers' // Show full pagination controls (previous, next, and page numbers)
      });
    });
  </script>
</body>

</html>