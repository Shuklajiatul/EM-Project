<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <h2 class="ms-3">SlashRTC</h2>

    <div class="ms-auto d-flex align-items-center">
      <!-- Dynamically display the user's name -->
      <span class="me-3 text-secondary fw-bold">Welcome, <?= session()->get('name') ?: 'Guest' ?></span>

      <!-- Show Data button -->
      <button class="btn btn-primary me-2" onclick="location.href='/students'">Show Data</button>

      <!-- Actions dropdown -->
      <div class="dropdown">
        <button class="btn btn-warning dropdown-toggle" type="button" id="actionMenu" data-bs-toggle="dropdown" aria-expanded="false">
          Actions
        </button>
        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="actionMenu">
          <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#uploadCsvModal">Upload CSV</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item" href="/download-csv">Download CSV</a></li>
        </ul>
      </div>

      <!-- Logout button -->
      <a href="#" onclick="confirmLogout()" class="btn btn-danger ms-3"><i class="fa-solid fa-right-from-bracket"></i>Logout</a>

    </div>
  </div>
</nav>

<script>
  function confirmLogout() {
    const isConfirmed = confirm("Are you sure you want to log out?");
    if (isConfirmed) {
      // Redirect to the logout page if confirmed
      window.location.href = '/logout';
    }
  }
</script>
