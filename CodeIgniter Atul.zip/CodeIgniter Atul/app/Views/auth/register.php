<!DOCTYPE html>
<html lang="en">
<head>
  <title>Register - Workplace Manager</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body {
      background: linear-gradient(to bottom right, #0008ff, #f21010);
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      color: white;
    }
    .register-card {
      padding: 2rem;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
      border-radius: 10px;
      background: white;
      color: black;
    }
    .register-card h2 {
      text-align: center;
      margin-bottom: 1.5rem;
    }
  </style>
</head>
<body>
  <div class="register-card">
    <form action="/register" method="post">
      <?= csrf_field() ?>
      <h2>Register</h2>
      <?php if (session()->getFlashdata('error')): ?>
        <script>
          Swal.fire('Error', '<?= session()->getFlashdata('error') ?>', 'error');
        </script>
      <?php endif; ?>
      <div class="mb-3">
        <label for="name">Full Name</label>
        <input type="text" name="name" class="form-control" placeholder="Enter your full name" required>
      </div>
      <div class="mb-3">
        <label for="email">Email</label>
        <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
      </div>
      <div class="mb-3">
        <label for="password">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
      </div>
      <div class="text-center">
        <button type="submit" class="btn btn-primary w-100">Register</button>
      </div>
    </form>
  </div>
</body>
</html>