<?= $this->extend('layouts/frontend.php') ?>

<?= $this->section('content') ?>

<div class="container-fluid min-vh-100">
  <div class="row">
    <div class="col-md-12">
      <div class="card shadow-lg border-0 rounded">
        <div class="card-header bg-primary text-white text-center">
          <h3 class="mb-0">Employee Data
          <a href="javascript:void(0);" class="btn btn-success btn-sm float-end" id="addDataBtn"><i class="fa-solid fa-user-plus"></i> Add Data</a>
            <button type="button" class="btn btn-info btn-sm float-end" data-bs-toggle="modal" data-bs-target="#searchModal" style="margin-right: 10px;">
              <i class="fa-solid fa-search"></i> Filter
            </button>
          </h3>
        </div>
        <div class="card-body bg-light">
          <table class="table table-striped table-bordered" id="myDataTable">
            <thead class="table-info">
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>   
                <th scope="col">Email</th>
                <th scope="col">Phone</th>
                <th scope="col">Company</th>
                <th scope="col" class="text-center">Delete</th>
              </tr>
            </thead>
            <tbody id="studentData">
              <?php if ($students): foreach ($students as $row): ?>
                <tr>
                  <td class="align-middle"><?= $row['id']; ?></td>
                  <td class="align-middle"><?= $row['name']; ?></td>
                  <td class="align-middle"><?= $row['email']; ?></td>
                  <td class="align-middle"><?= $row['phone']; ?></td>
                  <td class="align-middle"><?= $row['company']; ?></td>
                  <td class="text-center">
                  <button type="button" class="btn btn-warning btn-sm editStudentBtn" data-id="<?= $row['id']; ?>"><i class="fa-solid fa-pen-to-square"></i></button>
                    <button type="button" value="<?= $row['id']; ?>" class="confirm_del_btn btn btn-danger btn-sm"><i class="fa-solid fa-user-xmark"></i></button>
                  </td>
                </tr>
              <?php endforeach; endif; ?>
            </tbody>
          </table>
        </div>
        <div class="card-footer text-center bg-dark text-white">
          <p class="mb-0">© <?= date('Y'); ?> SlashRTC. All rights reserved.</p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Upload CSV Modal -->
<div class="modal fade" id="uploadCsvModal" tabindex="-1" aria-labelledby="uploadCsvModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="uploadCsvModalLabel">Upload CSV</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="/upload-csv" method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="modal-body">
          <div class="mb-3">
            <label for="csv_file" class="form-label">Select CSV File</label>
            <input class="form-control" type="file" name="csv_file" accept=".csv" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Upload</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Search Modal -->
<div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="searchModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title" id="searchModalLabel">Search Students</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="searchForm">
          <div class="form-group mb-3">
            <label for="search_id">ID</label>
            <input type="text" class="form-control" id="search_id" name="id" placeholder="Enter ID">
          </div>
          <div class="form-group mb-3">
            <label for="search_name">Name</label>
            <input type="text" class="form-control" id="search_name" name="name" placeholder="Enter Name">
          </div>
          <div class="form-group mb-3">
            <label for="search_email">Email</label>
            <input type="email" class="form-control" id="search_email" name="email" placeholder="Enter Email">
          </div>
          <div class="form-group mb-3">
            <label for="search_phone">Phone</label>
            <input type="text" class="form-control" id="search_phone" name="phone" placeholder="Enter Phone">
          </div>
          <div class="form-group mb-3">
            <label for="search_company">company</label>
            <input type="text" class="form-control" id="search_company" name="company" placeholder="Enter company">
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" id="searchBtn" class="btn btn-primary">Search</button>
      </div>
    </div>
  </div>
</div>


<!-- Add/Edit Student Modal -->
<div class="modal fade" id="studentModal" tabindex="-1" aria-labelledby="studentModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title" id="studentModalLabel">Add/Edit Student</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="studentForm">
          <input type="hidden" id="student_id" name="id">
          <div class="form-group mb-3">
            <label for="student_name">Name</label>
            <input type="text" class="form-control" id="student_name" name="name" placeholder="Enter Name" required>
          </div>
          <div class="form-group mb-3">
            <label for="student_email">Email</label>
            <input type="email" class="form-control" id="student_email" name="email" placeholder="Enter Email" required>
          </div>
          <div class="form-group mb-3">
            <label for="student_phone">Phone</label>
            <input type="text" class="form-control" id="student_phone" name="phone" placeholder="Enter Phone" required>
          </div>
          <div class="form-group mb-3">
            <label for="student_company">company</label>
            <input type="text" class="form-control" id="student_company" name="company" placeholder="Enter company" required>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" id="saveBtn" class="btn btn-primary">Save</button>
      </div>
    </div>
  </div>
</div>


<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<!-- Delete confirm -->
<script>
 $(document).ready(function() {
  $('.confirm_del_btn').click(function(e) {
    e.preventDefault();
    var id = $(this).val();
    var confirm = window.confirm("Are you sure you want to delete this data?");
    if (confirm) {
      $.ajax({
        url: "<?= base_url('students/confirm-delete/') ?>" + id,
        success: function(response) {
          window.location.reload();
          alert("Data deleted successfully");
        }
      });
    }
  });

  // Search functionality
  $("#searchBtn").click(function(e) {
    e.preventDefault();

    let searchData = {
      id: $("#search_id").val(),
      name: $("#search_name").val(),
      email: $("#search_email").val(),
      phone: $("#search_phone").val(),
      company: $("#search_company").val(),
    };

    $.ajax({
      url: "<?= base_url('students/search') ?>",
      type: "GET",
      data: searchData,
      dataType: "json",
      success: function(response) {
        if (response.status === "success") {
          let tableBody = $("#studentData");
          tableBody.empty();  // Clear existing table data

          if (response.data.length > 0) {
            response.data.forEach((row) => {
              tableBody.append(`
              <tr>
                <td class="align-middle">${row.id}</td>
                <td class="align-middle">${row.name}</td>
                <td class="align-middle">${row.email}</td>
                <td class="align-middle">${row.phone}</td>
                <td class="align-middle">${row.company}</td>
                <td class="text-center">
                  <a href="<?= base_url('students/edit/') ?>${row.id}" class="btn btn-warning btn-sm"><i class="fa-solid fa-pen-to-square"></i></a>
                  <button type="button" value="${row.id}" class="confirm_del_btn btn btn-danger btn-sm"><i class="fa-solid fa-user-xmark"></i></button>
                </td>
              </tr>
            `);
            });
          } else {
            tableBody.append('<tr><td colspan="6" class="text-center">No records found</td></tr>');
          }

          // Close modal and remove backdrop to fix Bootstrap overlay issue
          $("#searchModal").modal("hide");
          $(".modal-backdrop").remove();  // Remove the backdrop

          // Enable all buttons again after search
          $('button').prop('disabled', false);
        } else {
          alert("Error: " + response.message);
        }
      },
      error: function() { 
        alert("An error occurred during the search.");
      },
    });
  });
});

$(document).ready(function() {
  // Handle Add Data Button Click
  $("#addDataBtn").click(function() {
    // Reset form and prepare for adding new student
    $('#studentForm')[0].reset(); // Clear the form
    $('#student_id').val(''); // Clear hidden ID field
    $('#studentModalLabel').text('Add Student'); // Change modal title
    $('#saveBtn').text('Add'); // Set button text to Add
    $('#studentModal').modal('show'); // Show modal
  });

  // Handle Edit Button Click
  $('.editStudentBtn').click(function(e) {
    e.stopPropagation(); // Prevent the click event from bubbling up
    var id = $(this).data('id'); // Get the student ID
    console.log('Fetching student data for ID:', id); // Log the student ID
    $.ajax({
        url: "<?= base_url('students/edit') ?>/" + id,
        type: "GET",
        dataType: "json",
        success: function(response) {
            console.log('Server response:', response); // Log the server response
            if (response.status === 'success') {
                // Populate the modal with existing student data
                $('#student_id').val(response.data.id);
                $('#student_name').val(response.data.name);
                $('#student_email').val(response.data.email);
                $('#student_phone').val(response.data.phone);
                $('#student_company').val(response.data.company);

                $('#studentModalLabel').text('Edit Student'); // Change modal title to Edit
                $('#saveBtn').text('Save Changes'); // Change button text to Save Changes
                $('#studentModal').modal('show'); // Show modal
            } else {
                alert('Error fetching student data');
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX error:', status, error); // Log the error
            alert('Error fetching student data');
        }
    });
});

// Handle Save Button (Add/Edit)
$('#saveBtn').click(function() {
    var formData = $('#studentForm').serialize(); // Get form data
    var url = $('#student_id').val() ? "<?= base_url('students/update') ?>/" + $('#student_id').val() : "<?= base_url('students/store') ?>";
    var type = $('#student_id').val() ? "PUT" : "POST"; // POST for add, PUT for edit

    $.ajax({
        url: url,
        type: type,
        data: formData,
        success: function(response) {
            if(response.status === 'success') {
                $('#studentModal').modal('hide'); // Close modal
                location.reload(); // Reload the page to reflect changes
            } else {
                alert('Error updating student');
            }
        },
        error: function() {
            alert('Error updating student');
        }
    });
});

document.getElementById('searchBtn').addEventListener('click', function() {
    // Get form data
    const form = document.getElementById('searchForm');
    const formData = new FormData(form);

    // Send search data via AJAX (to keep the page from reloading)
    fetch('/search', {
      method: 'GET',
      body: formData
    })
    .then(response => response.json())
    .then(data => {
      if (data.status === 'success') {
        // Process results here (e.g., display them in a table)
        console.log(data.data);
      } else {
        // Handle no records found
        alert(data.message);
      }
    })
    .catch(error => {
      console.error('Error:', error);
    });
  });

});

</script>
<?= $this->endSection() ?>
