<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        // Ensure the user is logged in before accessing protected routes
        if (!session()->get('logged_in') && $request->getUri()->getPath() !== 'login' && $request->getUri()->getPath() !== 'register') {
            return redirect()->to('/login')->with('error', 'You must be logged in to access this page.');
        }

        // Redirect logged-in users trying to access the login page
        if (session()->get('logged_in') && $request->getUri()->getPath() === 'login') {
            return redirect()->to('/students');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // No action needed after request processing
    }
}
