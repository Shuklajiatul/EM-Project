<?php

namespace App\Controllers;

use App\Models\StudentModel;

class StudentController extends BaseController
{
  public function index(): string
  {
    $student = new StudentModel();
    $data['students'] = $student->findAll(); // Retrieve all students
    return view('students/index', $data);
  }

  public function search()
{
    $studentModel = new StudentModel();
    $builder = $studentModel->builder();

    // Get input values
    $id = $this->request->getGet('id');
    $name = $this->request->getGet('name');
    $email = $this->request->getGet('email');
    $phone = $this->request->getGet('phone');
    $company = $this->request->getGet('company');

    // Modify search query based on inputs
    if ($id) {
        // Ensure that the ID is matched exactly
        $builder->where('id', $id);
    }
    if ($name) $builder->like('name', $name);
    if ($email) $builder->like('email', $email);
    if ($phone) $builder->like('phone', $phone);
    if ($company) $builder->like('company', $company);

    // Get the results
    $results = $builder->get()->getResultArray();

    // If no results are found
    if (empty($results)) {
        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'No records found.',
        ]);
    }

    // Return the results
    return $this->response->setJSON([
        'status' => 'success',
        'data' => $results,
    ]);
}


  public function create()
  {
      return view('students/create');
  }
  
  public function store()
{
    $students = new StudentModel();
    $data = [
        'name' => $this->request->getPost('name'),
        'email' => $this->request->getPost('email'),
        'phone' => $this->request->getPost('phone'),
        'company' => $this->request->getPost('company'),
    ];

    if ($students->save($data)) {
        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Student added successfully!',
        ]);
    }

    return $this->response->setJSON([
        'status' => 'error',
        'message' => 'Error adding student!',
    ]);
}

  
public function update($id)
{
    $studentModel = new StudentModel();
    $data = [
        'name' => $this->request->getPost('name'),
        'email' => $this->request->getPost('email'),
        'phone' => $this->request->getPost('phone'),
        'company' => $this->request->getPost('company'),
    ];

    if ($studentModel->update($id, $data)) {
        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Student updated successfully!',
        ]);
    }

    return $this->response->setJSON([
        'status' => 'error',
        'message' => 'Error updating student!',
    ]);
}

  
public function edit($id)
{
    $studentModel = new StudentModel();
    $student = $studentModel->find($id);

    if (!$student) {
        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'Student not found',
        ]);
    }

    return $this->response->setJSON([
        'status' => 'success',
        'data' => $student,
    ]);
}

  

  public function confirmDelete($id = null)
  {
    $students = new StudentModel();
    $students->delete($id);
    return;
  }
}
