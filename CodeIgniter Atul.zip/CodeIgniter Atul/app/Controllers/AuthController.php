<?php

namespace App\Controllers;

use App\Models\UserModel;

class AuthController extends BaseController
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function login()
    {
        return view('auth/login');
    }

    public function processLogin()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        $user = $this->userModel->where('email', $email)->first();

        if (!$user || !password_verify($password, $user['password'])) {
            return redirect()->back()->with('error', 'Invalid email or password.');
        }

        // Set session and redirect
        session()->set([
            'user_id' => $user['id'],
            'name' => $user['name'], // Save user's name in the session
            'logged_in' => true
        ]);
        return redirect()->to('/students')->with('success', 'Login successful!');
    }

    public function register()
    {
        return view('auth/register');
    }

    public function processRegister()
    {
        $name = $this->request->getPost('name'); // Retrieve the name
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        // Check if user already exists
        $existingUser = $this->userModel->where('email', $email)->first();

        if ($existingUser) {
            return redirect()->back()->with('error', 'User already exists.');
        }

        // Save the user with name, email, and password
        $this->userModel->save([
            'name' => $name,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_BCRYPT),
        ]);

        return redirect()->to('/login')->with('success', 'Registration successful! Please login.');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login')->with('success', 'Logged out successfully.');
    }

    public function uploadCSV()
{
    $file = $this->request->getFile('csv_file'); // Replace 'csv_file' with your form field name
    if ($file && $file->isValid()) {
        $filePath = WRITEPATH . 'uploads/' . $file->getName();
        $file->move(WRITEPATH . 'uploads'); // Move file to writable/uploads

        $data = []; // Initialize data array to store valid rows

        if (($handle = fopen($filePath, 'r')) !== false) {
            $header = fgetcsv($handle); // Read CSV header
            log_message('debug', 'CSV Headers: ' . print_r($header, true));

            while (($row = fgetcsv($handle)) !== false) {
                $rowData = array_combine($header, $row);
                
                // Check for required primary key column
                if (!isset($rowData['id'])) {
                    log_message('error', 'Missing id in row: ' . print_r($rowData, true));
                    continue; // Skip invalid rows
                }

                $data[] = $rowData; // Add valid rows to $data
            }
            fclose($handle);
        }

        // Proceed with database insertion if $data is not empty
        if (!empty($data)) {
            return $this->insertNewData($data);
        } else {
            return redirect()->back()->with('error', 'No valid data to insert.');
        }
    } else {
        return redirect()->back()->with('error', 'Invalid file uploaded.');
    }
}

private function insertNewData($data)
{
    $db = \Config\Database::connect();
    $builder = $db->table('ci_students'); // Replace with your table name

    // Fetch the highest existing ID in the table
    $maxIdResult = $builder->selectMax('id')->get()->getRow();
    $maxId = $maxIdResult ? $maxIdResult->id : 0;

    $insertData = [];

    foreach ($data as $row) {
        // If ID exists, increment it to avoid duplicates
        if (isset($row['id'])) {
            $row['id'] = ++$maxId;  // Set new unique ID for each row
        }
        $insertData[] = $row;
    }

    // Insert new rows
    try {
        $builder->insertBatch($insertData); // Insert all rows from $data array
        return redirect()->back()->with('success', count($insertData) . " new rows inserted.");
    } catch (\Exception $e) {
        log_message('error', 'Insert failed: ' . $e->getMessage());
        return redirect()->back()->with('error', 'Failed to insert data.');
    }
}

public function downloadCSV()
{
    $db = \Config\Database::connect();
    $builder = $db->table('ci_students');
    $query = $builder->get();
    $data = $query->getResultArray();

    // Prepare CSV
    $filename = 'employee_data_' . date('Y-m-d') . '.csv';
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');

    $output = fopen('php://output', 'w');
    if (!empty($data)) {
        // Add headers
        fputcsv($output, array_keys($data[0]));
        // Add data
        foreach ($data as $row) {
            fputcsv($output, $row);
        }
    }
    fclose($output);
    exit;
}

}
