<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Default Route: Redirect to login page
$routes->get('/', 'AuthController::login');

// Authentication Routes
$routes->get('/login', 'AuthController::login');
$routes->post('/login', 'AuthController::processLogin');
$routes->get('/register', 'AuthController::register');
$routes->post('/register', 'AuthController::processRegister');
$routes->get('/logout', 'AuthController::logout');

// Restrict access to students page
$routes->get('/students', 'StudentController::index', ['filter' => 'auth']);

// Student Routes (accessible only after login)
$routes->get('/students/create', 'StudentController::create', ['filter' => 'auth']);
$routes->post('/students/add', 'StudentController::store', ['filter' => 'auth']);
$routes->post('/students/store', 'StudentController::store', ['filter' => 'auth']);
$routes->get('/students/edit/(:num)', 'StudentController::edit/$1', ['filter' => 'auth']);
$routes->put('/students/update/(:num)', 'StudentController::update/$1', ['filter' => 'auth']);
$routes->get('/students/confirm-delete/(:num)', 'StudentController::confirmDelete/$1', ['filter' => 'auth']);
$routes->get('/students/search', 'StudentController::search', ['filter' => 'auth']);


$routes->post('/upload-csv', 'AuthController::uploadCSV');
$routes->get('/download-csv', 'AuthController::downloadCSV');    